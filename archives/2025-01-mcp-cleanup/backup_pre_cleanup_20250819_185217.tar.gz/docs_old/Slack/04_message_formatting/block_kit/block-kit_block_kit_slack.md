---
title: "Block Kit | Slack"
source_url: "https://api.slack.com/block-kit"
scraped_date: "2025-08-19T15:43:11.864010"
description: "A clean and consistent UI framework for Slack apps"
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Block Kit | Slack

