---
title: "Reference: block elements & interactive components | Slack"
source_url: "https://api.slack.com/reference/block-kit/block-elements#multi_select"
scraped_date: "2025-08-19T15:43:11.868017"
description: "A comprehensive breakdown of elements that add images or interactivity to blocks."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Reference: block elements & interactive components | Slack

