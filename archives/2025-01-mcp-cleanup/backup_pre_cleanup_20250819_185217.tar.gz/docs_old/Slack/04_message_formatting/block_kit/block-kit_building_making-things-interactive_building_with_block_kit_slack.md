---
title: "Building with Block Kit | Slack"
source_url: "https://api.slack.com/block-kit/building#making-things-interactive"
scraped_date: "2025-08-19T15:43:11.866085"
description: "String the atoms together into molecules and inject them into messages and modals."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Building with Block Kit | Slack

