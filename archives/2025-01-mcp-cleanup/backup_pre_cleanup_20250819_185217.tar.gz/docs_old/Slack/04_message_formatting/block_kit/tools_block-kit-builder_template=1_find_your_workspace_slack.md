---
title: "Find your workspace | Slack"
source_url: "https://api.slack.com/tools/block-kit-builder?template=1"
scraped_date: "2025-08-19T15:43:11.867154"
description: "Find and sign in to your Slack workspace."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Find your workspace | Slack

