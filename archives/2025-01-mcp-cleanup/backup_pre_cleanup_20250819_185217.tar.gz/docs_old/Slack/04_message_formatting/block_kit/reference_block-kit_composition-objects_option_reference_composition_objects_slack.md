---
title: "Reference: composition objects | Slack"
source_url: "https://api.slack.com/reference/block-kit/composition-objects#option"
scraped_date: "2025-08-19T15:43:11.865155"
description: "A comprehensive breakdown of composition objects that define text, options, and other features within blocks and elements"
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Reference: composition objects | Slack

