---
title: "chat.postMessage method | Slack"
source_url: "https://api.slack.com/methods/chat.postMessage#arg_icon_url"
scraped_date: "2025-08-19T15:41:05.554079"
description: "Sends a message to a channel."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# chat.postMessage method | Slack

