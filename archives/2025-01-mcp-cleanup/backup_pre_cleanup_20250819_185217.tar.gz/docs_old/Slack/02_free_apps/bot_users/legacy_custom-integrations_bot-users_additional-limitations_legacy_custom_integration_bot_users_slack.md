---
title: "Legacy custom integration bot users | Slack"
source_url: "https://api.slack.com/legacy/custom-integrations/bot-users#additional-limitations"
scraped_date: "2025-08-19T15:41:05.553236"
description: "Outdated information about a kind of bot user that didn't live inside a Slack app."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Legacy custom integration bot users | Slack

