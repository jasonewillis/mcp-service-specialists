---
title: "Rate Limits | Slack"
source_url: "https://api.slack.com/apis/rate-limits"
scraped_date: "2025-08-19T15:43:45.508724"
description: "All good things in moderation: how rate limiting works throughout the Slack platform."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Rate Limits | Slack

