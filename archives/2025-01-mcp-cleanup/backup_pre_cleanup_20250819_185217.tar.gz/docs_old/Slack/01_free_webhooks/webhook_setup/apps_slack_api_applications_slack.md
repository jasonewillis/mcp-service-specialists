---
title: "Slack API: Applications | Slack"
source_url: "https://api.slack.com/apps"
scraped_date: "2025-08-19T15:39:53.053588"
description: ""
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Slack API: Applications | Slack

Go to SlackDocumentation Tutorials TwitterSuccess!Your AppsYou'll need to sign in to your Slack account to create an application. Don't see an app you're looking for? Sign in to another workspace. Using SlackProductEnterprisePricingSupportSlack GuidesSlack MarketplaceAPISlack JobsCustomersDevelopersEventsBlogLegalPrivacySecurityTerms of ServicePoliciesHandy LinksDownload desktop appDownload mobile appBrand GuidelinesSlack at WorkStatusContact Us