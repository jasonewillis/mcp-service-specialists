---
title: "Sending messages using incoming webhooks | Slack"
source_url: "https://api.slack.com/messaging/webhooks"
scraped_date: "2025-08-19T15:39:47.717171"
description: "Create an incoming webhook with a unique URL to which you send a JSON payload with message text and options."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Sending messages using incoming webhooks | Slack

