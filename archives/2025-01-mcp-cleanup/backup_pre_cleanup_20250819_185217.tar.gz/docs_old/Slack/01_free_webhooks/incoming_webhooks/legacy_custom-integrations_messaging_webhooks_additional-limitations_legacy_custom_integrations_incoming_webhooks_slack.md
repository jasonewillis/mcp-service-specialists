---
title: "Legacy custom integrations incoming webhooks | Slack"
source_url: "https://api.slack.com/legacy/custom-integrations/messaging/webhooks#additional-limitations"
scraped_date: "2025-08-19T15:39:47.717596"
description: "All about an outdated way to send messages to channels using approaches now actively discouraged."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Legacy custom integrations incoming webhooks | Slack

