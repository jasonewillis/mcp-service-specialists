---
title: "Understanding Slack Connect | Slack Developer Docs"
source_url: "https://docs.slack.dev/apis/slack-connect/"
scraped_date: "2025-08-19T15:44:29.434072"
description: "Shared Channels allows you to collaborate with an external org!"
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Understanding Slack Connect | Slack Developer Docs

