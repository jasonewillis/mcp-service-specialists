---
title: "Slack APIs | Slack Developer Docs"
source_url: "https://docs.slack.dev/apis#events-api"
scraped_date: "2025-08-19T15:44:29.433104"
description: "Every Slack app and workflow has access to a range of APIs that provide access to read, write, and update many types of data in Slack."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Slack APIs | Slack Developer Docs

