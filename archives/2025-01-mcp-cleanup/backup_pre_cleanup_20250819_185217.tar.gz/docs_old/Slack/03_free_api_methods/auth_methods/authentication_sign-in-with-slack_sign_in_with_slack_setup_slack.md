---
title: "Sign in with Slack setup | Slack"
source_url: "https://api.slack.com/authentication/sign-in-with-slack"
scraped_date: "2025-08-19T15:42:17.307009"
description: "Our OAuth-based sign-in flow uses the OpenID Connect protocol to let users sign into your service using Slack."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Sign in with Slack setup | Slack

