---
title: "Verifying requests from Slack | Slack"
source_url: "https://api.slack.com/authentication/verifying-requests-from-slack"
scraped_date: "2025-08-19T15:42:17.307184"
description: "Slack signs its requests using a secret that's unique to your app. With the help of signing secrets, your app can more confidently verify whether requests from us are authentic."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Verifying requests from Slack | Slack

