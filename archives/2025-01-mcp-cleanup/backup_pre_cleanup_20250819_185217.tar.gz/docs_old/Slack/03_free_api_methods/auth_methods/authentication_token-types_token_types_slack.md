---
title: "Token types | Slack"
source_url: "https://api.slack.com/authentication/token-types"
scraped_date: "2025-08-19T15:42:17.308180"
description: "A tour of token types and their permission models, cornerstones of working with the Slack platform."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Token types | Slack

