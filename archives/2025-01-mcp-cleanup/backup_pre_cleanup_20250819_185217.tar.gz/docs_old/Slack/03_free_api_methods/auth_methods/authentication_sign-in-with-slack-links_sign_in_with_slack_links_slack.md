---
title: "Sign in with Slack links | Slack"
source_url: "https://api.slack.com/authentication/sign-in-with-slack-links"
scraped_date: "2025-08-19T15:42:17.307900"
description: "Create custom links that let users sign into your service using Slack."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Sign in with Slack links | Slack

