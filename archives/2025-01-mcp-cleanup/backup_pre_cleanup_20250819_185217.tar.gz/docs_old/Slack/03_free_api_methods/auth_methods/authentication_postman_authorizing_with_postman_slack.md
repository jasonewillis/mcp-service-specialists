---
title: "Authorizing with Postman | Slack"
source_url: "https://api.slack.com/authentication/postman"
scraped_date: "2025-08-19T15:42:17.307532"
description: "Authorizing with Postman."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Authorizing with Postman | Slack

