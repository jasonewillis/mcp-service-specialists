---
title: "Migration guide for classic apps | Slack"
source_url: "https://api.slack.com/authentication/migration"
scraped_date: "2025-08-19T15:42:17.307714"
description: "Everything you need to know to migrate your classic app to use the new granular permissions model."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Migration guide for classic apps | Slack

