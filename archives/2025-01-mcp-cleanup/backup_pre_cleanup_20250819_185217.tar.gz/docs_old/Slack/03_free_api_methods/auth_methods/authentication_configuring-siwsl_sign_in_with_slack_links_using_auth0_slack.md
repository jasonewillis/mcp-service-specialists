---
title: "Sign in with Slack links using Auth0 | Slack"
source_url: "https://api.slack.com/authentication/configuring-siwsl"
scraped_date: "2025-08-19T15:42:17.308041"
description: "Configure custom links to be used with Sign in with Slack using Auth0."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Sign in with Slack links using Auth0 | Slack

