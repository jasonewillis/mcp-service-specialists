---
title: "Installing with OAuth | Slack"
source_url: "https://api.slack.com/authentication/oauth-v2"
scraped_date: "2025-08-19T15:42:17.307346"
description: "Using an Oauth 2.0 flow to create Slack apps with precise permissions."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Installing with OAuth | Slack

