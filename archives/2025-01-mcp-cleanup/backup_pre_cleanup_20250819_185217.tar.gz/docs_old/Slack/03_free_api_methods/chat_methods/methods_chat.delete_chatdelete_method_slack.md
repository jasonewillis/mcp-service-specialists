---
title: "chat.delete method | Slack"
source_url: "https://api.slack.com/methods/chat.delete"
scraped_date: "2025-08-19T15:41:49.377711"
description: "Deletes a message."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# chat.delete method | Slack

