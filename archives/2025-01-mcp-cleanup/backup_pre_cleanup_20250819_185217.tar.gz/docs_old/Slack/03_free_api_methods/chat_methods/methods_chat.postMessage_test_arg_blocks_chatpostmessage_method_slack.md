---
title: "chat.postMessage method | Slack"
source_url: "https://api.slack.com/methods/chat.postMessage/test#arg_blocks"
scraped_date: "2025-08-19T15:41:49.381663"
description: "Sends a message to a channel."
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# chat.postMessage method | Slack

