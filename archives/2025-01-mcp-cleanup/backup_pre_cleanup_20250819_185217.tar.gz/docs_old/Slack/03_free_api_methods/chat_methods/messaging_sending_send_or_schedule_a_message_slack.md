---
title: "Send or schedule a message | Slack"
source_url: "https://api.slack.com/messaging/sending"
scraped_date: "2025-08-19T15:41:49.378358"
description: "Transform monologues into conversations, and conversations into workflows, by learning how apps can publish messages"
tier: "FREE"
category: "slack_integration"
note: "Documentation filtered for FREE tier features only"
---
**Note: This documentation covers FREE tier features only**

# Send or schedule a message | Slack

